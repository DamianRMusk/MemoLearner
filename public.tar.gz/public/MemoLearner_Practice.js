document.getElementById('google_signin_button').addEventListener('click', event => signUp() )
document.getElementById('google_signout_button').addEventListener('click', event => signOut() )
function open_navigation_bar() {
    document.getElementById("side_navigation_bar").style.width = "15%";
    if (document.getElementById("side_navigation_bar").style.width == "15%"){
        document.getElementById("hamburger_menu_icon").style.transform = 'rotate(90deg)';
    }
}
function close_navigation_bar() {
    document.getElementById("side_navigation_bar").style.width = "0px";
}
function signUp(){
    var provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider).then(function(result) {
     // This gives you a Google Access Token. You can use it to access the Google API.
    var token = result.credential.accessToken;
     // The signed-in user info.
     var user = result.user;
    window.location.href = "/index.html";
        // ...
    }).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});
firebase.auth().getRedirectResult().then(function(result) {
  if (result.credential) {
    // This gives you a Google Access Token. You can use it to access the Google API.
    var token = result.credential.accessToken;
    // ...
  }
  // The signed-in user info.
  user = result.user;
}).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});
// Step 1.
// User tries to sign in to Google.
auth.signInWithPopup(new firebase.auth.GoogleAuthProvider()).catch(function(error) {
  // An error happened.
  if (error.code === 'auth/account-exists-with-different-credential') {
    // Step 2.
    // User's email already exists.
    // The pending Google credential.
    var pendingCred = error.credential;
    // The provider account's email address.
    var email = error.email;
    // Get registered providers for this email.
    auth.fetchProvidersForEmail(email).then(function(providers) {
      // Step 3.
      // If the user has several providers,
      // the first provider in the list will be the "recommended" provider to use.
      if (providers[0] === 'password') {
        // Asks the user his password.
        // In real scenario, you should handle this asynchronously.
        var password = promptUserForPassword(); // TODO: implement promptUserForPassword.
        auth.signInWithEmailAndPassword(email, password).then(function(user) {
          // Step 4a.
          return user.link(pendingCred);
        }).then(function() {
          // Google account successfully linked to the existing Firebase user.
          goToApp();
        });
        return;
      }
      // All the other cases are external providers.
      // Construct provider object for that provider.
      // TODO: implement getProviderForProviderId.
      var provider = getProviderForProviderId(providers[0]);
      // At this point, you should let the user know that he already has an account
      // but with a different provider, and let him validate the fact he wants to
      // sign in with this provider.
      // Sign in to provider. Note: browsers usually block popup triggered asynchronously,
      // so in real scenario you should ask the user to click on a "continue" button
      // that will trigger the signInWithPopup.
      auth.signInWithPopup(provider).then(function(result) {
        // Remember that the user may have signed in with an account that has a different email
        // address than the first one. This can happen as Firebase doesn't control the provider's
        // sign in flow and the user is free to login using whichever account he owns.
        // Step 4b.
        // Link to Google credential.
        // As we have access to the pending credential, we can directly call the link method.
        result.user.link(pendingCred).then(function() {
          // Google account successfully linked to the existing Firebase user.
          goToApp();
        
        });
      });
    });
  }
});
}
function signOut(){
  firebase.auth().signOut().then(function() {
  // Sign-out successful.
  window.location.href = "/index.html";
}).catch(function(error) {
  // An error happened.
});
}
var user = firebase.auth().currentUser;
var name, email, photoUrl, uid, emailVerified;
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    // User is signed in.
    if (user != null) {
      name = user.displayName;
      email = user.email;
      photoUrl = user.photoURL;
      emailVerified = user.emailVerified;
      uid = user.uid;  // The user's ID, unique to the Firebase project. Do NOT use
                   // this value to authenticate with your backend server, if
                   // you have one. Use User.getToken() instead.
    }
    else {
      
    }
    document.getElementById("welcome_heading").innerHTML = "Welcome, " + name + "!";
    document.getElementById("google_login_button").style.display = "none"
  } else {
    // No user is signed in.
    document.getElementById("google_signout_button").style.display = "none"
  document.getElementById("welcome_heading").innerHTML = "You are currently using MemoLearner as a guest! Please log in, to access all our content!";
    document.getElementById("sign_out_div").style.display = "none";
  }
});

const emojis =
['Φ','ͳ','ʹ','͵','Ͷ','͹',' ͅ','ͻ',';','ͽ','ɤ','͸','Ȑ','Ϊ','Ψ','Ρ','Κ','ȏ','Ȋ'
,'ȍ','Ω','Ό','΍','ͼ','ǵ','Ȝ','ȋ','Ȃ','ȕ','ȟ','❤']
const timer = document.getElementById('timer')
const question = document.getElementById('question_text')
const wordBox = document.getElementById('wordbox')
const correctButton = document.getElementById("correct_button")
const incorrectButton = document.getElementById("incorrect_button")

const emojiForm = document.getElementById('emoji')
const secondaryHeading = document.getElementById("secondary_heading")
const model =
{ difficulty: 0
, timeLeft: 20
, timerId: 0
, randomEmojis: []
, randomEmojisUnique: []
, randomEmojiCharacter: ''
, randomEmojiCharacterFrequency: 0
, currentEmoji: 0
, score: 0
}
const changeState = state => {
let classes = document.body.classList.length
for (let i = 0; i < classes; i++)
document.body.classList.remove(document.body.classList.item(i))
document.body.classList.add(state)
}
const endTimer = () => model.timeLeft = 0

const random = end => {
const randomZeroToOne = Math.random()
const randomZeroToEnd = randomZeroToOne * end
const randomZeroToEndMinusOne = Math.floor(randomZeroToEnd)
return randomZeroToEndMinusOne
}
const arrayOfSize = size => {
const array = []
for (let i = 0; i < size; i++)
array.push(undefined)
return array
}
const randomEmojis = size => {
const arrayOfRandomNumbers = arrayOfSize(size).map(() =>
random(emojis.length))
const arrayOfRandomEmojis = arrayOfRandomNumbers.map(randomNumber =>
emojis[randomNumber])
return arrayOfRandomEmojis
}
const countDownWithTimeLeft = () => {
timer.innerHTML = `${model.timeLeft--} Second${model.timeLeft ? 's' : ''}
Remaining!`
}
const countDownWithNoTimeLeft = () => {
clearInterval(model.timerId)
next()
}
const countDown = () => {
model.timeLeft
? countDownWithTimeLeft()
: countDownWithNoTimeLeft()
}
const startCountDown = () =>
model.timerId = setInterval(countDown, 1000)
const correctAnswer = () => {
changeState('correct')

model.score++
correctButton.value = 'Correct! Next →'
}
const incorrectAnswer = correctFrequency => {
changeState('incorrect')
incorrectButton.value = `Incorrect! The correct answer was ${correctFrequency}!
Next →`
}
const submitAnswer = event => {
event.preventDefault()
model.randomEmojiCharacterFrequency == wordBox.value
? correctAnswer()
: incorrectAnswer(model.randomEmojiCharacterFrequency)
}
const showScore = () => {
changeState('score')
secondaryHeading.innerHTML =
model.score == model.randomEmojisUnique.length
? `Now your memory is ever so slightly better! You got ${model.score} correct
out of ${model.randomEmojisUnique.length}! Amazing!`
: model.randomEmojisUnique.length - model.score <= 2
? `Now your memory is ever so slightly better! You got ${model.score} correct
out of ${model.randomEmojisUnique.length}! Great job!`
: model.randomEmojisUnique.length - model.score == 3
? `Now your memory is ever so slightly better! You got ${model.score} correct

out of ${model.randomEmojisUnique.length}! Good job!`
: `You got ${model.score} correct out of

${model.randomEmojisUnique.length}! Don\'t worry, you\'ll do better next time!`
}
const next = () => {
if (model.randomEmojisUnique.length == model.currentEmoji)
showScore()
else {
changeState('question')
model.randomEmojiCharacter =
model.randomEmojisUnique[model.currentEmoji++]

model.randomEmojiCharacterFrequency = model.randomEmojis.filter(emoji =>
emoji == model.randomEmojiCharacter).length
showQuestion()
}
}
const showQuestion = () => {
wordBox.focus()
wordBox.value = ''
wordBox.style.width = '40px'
question.innerHTML = `How many ${model.randomEmojiCharacter} were there?`
}
const startSequence = length => {
changeState('memorize')
model.randomEmojis = randomEmojis(length)
model.randomEmojisUnique = model.randomEmojis.reduce((acc, current) =>
acc.includes(current) ? acc : acc.concat([current]), [])
wordBox.value = model.randomEmojis.join('')
wordBox.style.width = length * 35 + 'px'
startCountDown()
}
 
 $(document).ready(function () {
      /* $("#wordbox").css("display", "none");
       $("#timer_ender_button").css("display", "none");
       $("#timer_div").css("display", "none");
       $("#submit_button").css("display", "none");
       $("#secondary_heading").text("Select Your Difficulty!");*/
       $("#difficulty_div").css("display", "block");
       $("#wordbox").css("display","none");
       $("#timer_ender_button").css("display", "none");
       $("#submit_button").css("display", "none");
       $("#secondary_heading").text("Select Your Difficulty!");
       $("#reload_button").css("display", "none")
       $("#how_to_play_div").css("display", "none")
   });
//console.log(question());
